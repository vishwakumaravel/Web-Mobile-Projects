import random
import flask as fk
import logging

logging.basicConfig(level=logging.DEBUG)

app = fk.Flask(
	__name__,
	template_folder='templates',
	static_folder='static'
)

form = """
<form method = "post" action="/testform">
<input name = "q">
<input type = "submit">
</form>
"""

@app.route('/')
def base_page():
  logging.info("****** MainPage GET ******")
  return(form)

@app.route('/testform', methods = ['POST'])
def testform():
    logging.info("****** TestForm POST ******")
    q = fk.request.form["q"]
    logging.info("*** q=" + str(q) + " type=" + str(type(q)))
    return(q)


if __name__ == "__main__":
	app.run(
		host='0.0.0.0',
		port=random.randint(2000, 9000)
    )
  