reproduce the following page using the HTML tags from the first presentation.

It should look like the following (except for the green border)

 

.