import flask as fk
import re
import logging
from replit import db
import datetime
import sqlite3

app = fk.Flask(
    __name__,
    static_folder="static",
    template_folder="templates",
)

connection = sqlite3.connect("blogbosts.db")
cursor = connection.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS AsciiArt (title TEXT, body TEXT, created TEXT)")

def render_ascii(error):
  with sqlite3.connect('blogbosts.db') as con:
    cursor = con.cursor()
    s = cursor.execute("SELECT * FROM AsciiArt ORDER BY created DESC")
    return(fk.render_template('home.html', error=error, arts=s))

@app.route('/', methods=["GET", "POST"])
def root():
    method = fk.request.method
    if method == "GET":
      logging.info("********** root GET **********")
      return fk.render_template('home.html', arts=[], error="")
    elif method == "POST":
        logging.info("********** root POST **********")
        connection = sqlite3.connect("blogbosts.db")
        cursor = connection.cursor()
        date = datetime.datetime.now()
        title = fk.request.form['title']
        art = fk.request.form['art']
    if title == '' or art == '':
       return(render_ascii("Need both a title and some artwork!"))
    else:
        cursor.execute("CREATE TABLE IF NOT EXISTS AsciiArt (title TEXT, body TEXT, created TEXT)")
        cursor.execute("INSERT INTO AsciiArt (title, body, created) VALUES (?, ?, ?)", (title, art, date))
        connection.commit()
        s = cursor.execute("SELECT * FROM AsciiArt ORDER BY created DESC")
        return(fk.render_template('home.html', error = '', arts = s))

app.run(host='0.0.0.0', port='3000')

