# Lab: BLOG-1
import flask as fk
import re
import logging
import sqlite3
import datetime
from dateutil import tz

def write_posts(posts=""):
  return fk.render_template('posts.html', posts=posts)

def write_perma_post(post=""):
  return fk.render_template('post.html', post=post)
  
def write_new_post(subject="", content="", error=""):
    return fk.render_template("newpost.html", ph_subject=subject, ph_content=content, ph_error=error)
  
def get_connection():
  conn = sqlite3.connect("blogbosts.db")
  conn.row_factory = dict_factory
  return conn

def to_cst(time):
  fzone = tz.gettz('UTC')
  tzone = tz.gettz("America/Chicago")
  time = time.replace(tzinfo=fzone)
  return time.astimezone(tzone)

app = fk.Flask(
  __name__,
  static_folder="stylesheets"  
)

def dict_factory(cursor, row):
  d = {}
  for index, col in enumerate(cursor.description):
    d[col[0]] = row[index]
  return d

def get_posts():
  with get_connection() as con:
    cursor = con.cursor()
    s = cursor.execute("SELECT * FROM posts ORDER BY create_date DESC LIMIT 10")
    return(s)

def get_fav():
    return("hello!")

@app.route('/', methods=["GET"])
@app.route('/blog', methods=["GET"], strict_slashes=False)
def root():
    method = fk.request.method
    with sqlite3.connect("blogbosts.db") as con:
        cursor = con.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, create_date TEXT, subject TEXT, content TEXT)")
        s = cursor.execute("SELECT * FROM posts ORDER BY create_date DESC")
        print([x for x in s])
        if method == "GET":
            return(write_posts(get_posts()))

@app.route('/newpost', methods=["GET", "POST"])
def new_post():
  method = fk.request.method
  if method == "GET":
    return(write_new_post())
  elif method == "POST":
    subject = fk.request.form["subject"]
    content = fk.request.form["content"]
    error = ""
    print(subject, content, error)
    if subject == "" or content == "":
      error = "Need both a subject and some content!"
      return(write_new_post(subject=subject, content=content, 
        error=error))
    else:
      currdate = datetime.datetime.now()
      currdate = to_cst(currdate)
      currdate = currdate.strftime("%A %B %d, %Y") + " " + currdate.strftime("%X %z")
      insert_vals  = (currdate, subject, content)
      with get_connection() as con:
        cursor = con.cursor()
        cursor.execute("INSERT INTO posts (create_date, subject, content) VALUES (?, ?, ?)", insert_vals)
        s = cursor.execute("SELECT id FROM posts WHERE create_date=?", (currdate, ))
        nid = s.fetchone()['id']
        print(nid)
    return fk.redirect(fk.url_for('permapost', post_id=nid))
      
    

@app.route('/blog/<post_id>', methods=["GET"])
def permapost(post_id):
  with get_connection() as con:
    cursor = con.cursor()
    s = cursor.execute("SELECT * FROM posts WHERE id=?", (post_id,))
    post = s.fetchone()
    print(post)
    return(write_perma_post(post))

app.run(host='0.0.0.0', port='3000')