import flask as fk
import random
import logging
import html
import re
from flask import redirect, url_for, request


def valid_user(user):
    print(user)
    try:
        ret = re.search("^[a-zA-z0-9_-]{3,20}$", user).group(0) == user
    except AttributeError:
        ret = False

    return ret


def valid_pass(p):
    print(p)
    try:
        ret = re.search(".{3,20}$", p).group(0) == p
    except AttributeError:
        ret = False

    return ret


def valid_email(em):
    try:
        ret = re.search("^\S+@\S+\.\S+$", em).group(0) == em
    except AttributeError:
        ret = False

    return ret


form = """
<link href="style.css" rel="stylesheet" type="text/css" />
<b> Signup </b>
<br>
<br>
<form method = "POST" action="/formPage">
<label>Username</label><input id = "lb1" type = "text" name="username" val=%(user)s> <div style = "color: red">%(error1)s</div> <br>
<label>Password</label><input id = "lb2" type = "text" name="password" val=%(p)s> <div style = "color: red">%(error2)s</div> <br>
<label>Verify Password</label><input id = "lb3" type = "text" name="verify-password" val=%(p1)s> <div style = "color: red">%(error3)s</div> <br>
<label> Email (optional) </label><input id = "lb4" type = "text" name= "email" val=%(em)s> <div style = "color: red">%(error4)s</div>
<input type ="submit"/>
</form>

<style>

b{
  font-size: 26px;
  color: red;
}
label{
  color: blue;
}
#lb1{
  margin-left: 45px;
}

#lb2{
  margin-left: 49px;
}

#lb3{
  margin-left: 5px; 
}
#lb4{
  margin-left: 1px;
}
</style>

"""

success = """
    <!DOCTYPE HTML>
    <link href="style.css" rel="stylesheet" type="text/css" />
<html>

<h1> Welcome, %(username)s! </h1>

<img src="https://quotefancy.com/media/wallpaper/3840x2160/6364313-Bill-Bradley-Quote-Ambition-is-the-path-to-success-Persistence-is.jpg" alt="" width="400px" length="400px">

</html>


"""


def escape_html(s):
    return html.escape(s)


def write_form(username="", password="", passV="", email="", error1="", error2="", error3="", error4=""):
    return (form % {
        "error1": error1,
        "error2": error2,
        "error3": error3,
        "error4": error4,
        "user": username,
        "p": password,
        "p1": passV,
        "em": email
        })


app = fk.Flask(__name__, template_folder='templates', static_folder='static')


@app.route('/')
def hello_world():
    return write_form()


@app.route('/formPage', methods=["GET", "POST"])
def root():
    method = fk.request.method
    valid = False
    myerror1=""
    myerror2=""
    myerror3=""
    myerror4=""
    print("in root")
    if method == "GET":
        return write_form()
    elif method == "POST":
        global username
        username = fk.request.form["username"]
        password = fk.request.form["password"]
        passV = fk.request.form["verify-password"]
        email = fk.request.form["email"]
        if valid_user(username) == False:
          print("Username Wrong")
          myerror1 = "Username Wrong"
        if valid_pass(password) == False:
          print("Passwords Wrong")
          myerror2 = "Passwords Wrong"
        if password == passV:
          print("Passwords match")
          myerror3 = ""
        else:
          print("Passwords do not match")
          myerror3 = "Passwords do not match"
        if valid_email(email) == False:
          print("Wrong Email")
          myerror4 = "Wrong Email"
        if myerror1=="" and myerror2=="" and myerror3=="" and myerror4=="":
          valid = True
        if valid:
          print("MAde it!")
          return redirect(url_for("welcome", username=username)) 
        else:
           #print(valid_pass(passV))
          return (write_form(error1=myerror1,error2=myerror2,error3=myerror3,error4=myerror4,
                           username=username,
                           password=password,
                           passV=passV,
                           email=email))


@app.route('/welcome', methods=["GET", "POST"])
def welcome ():
    print("yooo")
    return (success % {"username": username})


app.run(host='0.0.0.0', port='3000')
