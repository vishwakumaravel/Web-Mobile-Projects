# See the finished product here: https://Cookies-2.alexyang4.repl.co
import flask as fk
import logging
import hashlib

def write_site(message=""):
    return fk.render_template('main.html', message=message)

def hash_str(s): 
  #return the hashdigest created byhashlib's md5 hash of str(s).encode("utf-8")
  return hashlib.md5(str(s).encode("utf-8")).hexdigest()

def make_secure_val(s):
  return("s + '|' + hash_str(s)))")
    # return string that is a concatenation of s + '|' + hash_str(s))) - '+' symbols represent a concatenation operations.

# Take the string with  visits and the hash and return the confirmed results.
def check_secure_val(h):
    h_arr = h.split("|")
    s = h_arr[0]
    hash = h_arr[1]
    return s if hash_str(s) == hash else None
  #Python uses the keyword None to define null objects and variables

app = fk.Flask(
    __name__,
    static_folder="stylesheets"
)

def get_msg(visits):
    msg = "Visits: %i" % visits
    if visits == 10000: msg = "Congrats! You are our 10,000th customer!"
    return msg

@app.route('/', methods=["GET"])
def root():
    method = fk.request.method
    if method == "GET":
        msg = ""
        # Get the number of visits from the request's cookie
        hash_visits = fk.request.cookies.get('visits')
        if hash_visits:
          visits = check_secure_val(hash_visits)
            # Get the confirmed number of visits in hash_visits by calling check_secure_val 
          if visits:
            visits = int(visits.split("=")[-1])
            visits += 1
            msg = get_msg(visits)
                #update the visits count
          else:
            visits = 1
            msg = "Don't mess with my cookie!"
                # Warn the user "Don't mess with my cookie!"
        else:
            visits = 1
            msg=get_msg(visits)
        # Prepare the response object
        resp = fk.make_response(write_site(msg))
        # Set the response's cookie with 'visits', by making a _secure_val
        resp.set_cookie("visits", make_secure_val("visits=%i" % visits))
        return(resp)

app.run(host='0.0.0.0', port='3000')