
var currentdate = new Date();
var datetime = "Last Sync: " + currentdate.getDay() + "/" + currentdate.getMonth() 
+ "/" + currentdate.getFullYear() + " @ " 
+ currentdate.getHours() + ":" 
+ currentdate.getMinutes() + ":" + currentdate.getSeconds();

console.log(currentdate.getMonth());

var divItems = document.getElementsByClassName("container")[0].children;

function clear() {
    for(var i=0; i < divItems.length; i++) {
        var item = divItems[i];
        item.style.backgroundColor = 'aqua';
    }
}

function selected(item) {
    this.clear();
    item.style.backgroundColor = 'red';
}

var years = [];
for(let i = 2021; i > 1899; i-- ){
  years[i-2021] = i;
 document.getElementById("myYear").innerHTML += '<option value = "' + i + '">' + i + '</option>';
}

var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

for(let i = 0; i < 12; i++ ){ 
 document.getElementById("myMonth").innerHTML += '<option value = "' + months[i] + '">' + months[i] + '</option>';
}


