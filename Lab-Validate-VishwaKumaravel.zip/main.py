import flask as fl
import random
import logging
import html
from flask import redirect,url_for,request

logging.basicConfig(level=logging.DEBUG)

form = """
What is your birthday <br>
<form method = "POST" action="/formPage">
<label>Month</label><input type = "text" name="month" val=%(m)s>
<label>Day</label><input type = "number" name="day" val=%(d)s>
<label>Year</label><input type = "number" name="year" val=%(y)s><br>
<div style = "color: red">%(error)s</div>
<input type ="submit"/>
</form>
"""

def valid_day(d):
  return(0< d< 32)

def valid_month(m):
  months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  for x in months:
    if m.startswith(x): return(True)
  return(False)

def valid_year(y):
  return(1900 < y < 2021)

def valid_date(m, d, y):
  #logging.info("********************I am here")
  if d.isdigit() and y.isdigit():
    #logging.info("********************I am here22222222222")
    d = int(d)
    y = int(y)
    return(valid_day(d) and valid_month(m) and valid_year(y))
  return False

app = fl.Flask(
	__name__
)

def escape_html(s):
  return html.escape(s)

def write_form(month="", d="", y="", error=""):
  return(form % {"error": error, "m": month, "d":d, "y": y})

@app.route('/')
def hello_world ():
    return write_form()

@app.route('/formPage', methods=['POST'])
def form_handler ():
  method = fl.request.method
  logging.info("in form_handler")
  if method=="GET":
    return write_form()
  elif method == "POST":
    month = fl.request.form["month"]
    day = fl.request.form["day"]
    year = fl.request.form["year"]
    valid = valid_date(month, day, year)
    if valid:
      return redirect(url_for("success")) 
    else: 
      return (write_form(month=month, d=int(day), y = int(year), error = "That aint right"))

@app.route('/success')
def success ():
  return ("Thanks, the day exists")


#def base_page(error=""):
#    return write_form(error)

#@app.route('/', methods=['GET', 'POST'])
#def base_page(error=""):
#    return write_form(error)

#@app.route('/', methods=['GET', 'POST'])
#def form_handler():

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=random.randint(2000, 9000))












   # if (valid_date(request.form ['month'],request.form['day'],request.form['year'])):
   # return ("Thanks, the day exists")
 # else:
   # return ("Thanks, the day does not exist :( Please fix errors...")
    
