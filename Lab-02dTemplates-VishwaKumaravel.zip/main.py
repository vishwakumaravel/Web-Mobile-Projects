import flask as fk
import random
import logging
import html
import re
from flask import redirect, url_for, request, render_template


def valid_user(user):
    print(user)
    try:
        ret = re.search("^[a-zA-z0-9_-]{3,20}$", user).group(0) == user
    except AttributeError:
        ret = False

    return ret


def valid_pass(p):
    print(p)
    try:
        ret = re.search(".{3,20}$", p).group(0) == p
    except AttributeError:
        ret = False

    return ret


def valid_email(em):
    try:
        ret = re.search("^\S+@\S+\.\S+$", em).group(0) == em
    except AttributeError:
        ret = False

    return ret



def escape_html(s):
    return html.escape(s)

def write_form(error1="", error2="", error3="", error4=""):
    return (render_template("home.html", error1=error1,         error2=error2, error3=error3, error4=error4))



app = fk.Flask(__name__,template_folder='templates', static_folder='static')


@app.route('/')
def hello_world():
    return write_form()


@app.route('/formPage', methods=["GET", "POST"])
def root():
    method = fk.request.method
    valid = False
    myerror1=""
    myerror2=""
    myerror3=""
    myerror4=""
    print("in root")
    if method == "GET":
        return write_form()
    elif method == "POST":
        global username
        username = fk.request.form["username"]
        password = fk.request.form["password"]
        passV = fk.request.form["verify-password"]
        email = fk.request.form["email"]
        if valid_user(username) == False:
          print("Username Wrong")
          myerror1 = "Username Wrong"
        if valid_pass(password) == False:
          print("Passwords Wrong")
          myerror2 = "Passwords Wrong"
        if password == passV:
          print("Passwords match")
          myerror3 = ""
        else:
          print("Passwords do not match")
          myerror3 = "Passwords do not match"
        if valid_email(email) == False:
          print("Wrong Email")
          myerror4 = "Wrong Email"
        if myerror1=="" and myerror2=="" and myerror3=="" and myerror4=="":
          valid = True
        if valid:
          print("MADE IT")
          return redirect(url_for("welcome", username=username))
        else:
           return write_form(error1=myerror1, error2=myerror2, error3=myerror3, error4=myerror4, )


@app.route('/welcome', methods=["GET", "POST"])
def welcome ():
    return render_template("welcome.html", username=username)


app.run(host='0.0.0.0', port='3000')